import { Product, Division } from '../types';
import { PRODUCTS } from '../constants';

const initialProducts: Product[] = PRODUCTS.map(p => ({
  ...p,
  price: p.base_price,
  image_url: `https://picsum.photos/seed/${p.id}/400/300`
}));

export const getProducts = (): Promise<Product[]> => {
  return new Promise(resolve => {
    // Simulate network delay
    setTimeout(() => {
      resolve(initialProducts);
    }, 500);
  });
};

export const simulatePriceUpdate = (currentProducts: Product[], division: Division): Product[] => {
  return currentProducts.map(product => {
    // Fluctuation between -5% and +5%
    const fluctuation = (Math.random() - 0.5) * 0.1;
    const newBasePrice = product.base_price * (1 + fluctuation);
    const regionalPrice = Math.round(newBasePrice * division.price_multiplier);

    return {
      ...product,
      price: regionalPrice,
    };
  });
};