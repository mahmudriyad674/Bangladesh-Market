
import React from 'react';
import { BasketIcon } from './icons';

const SplashScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-emerald-600 text-white">
      <div className="animate-pulse">
        <BasketIcon className="h-24 w-24 mb-4" />
      </div>
      <h1 className="text-3xl font-bold font-['Hind_Siliguri']">বাংলাদেশ বাজার মূল্য</h1>
      <p className="mt-2 text-lg">সর্বশেষ দাম লোড হচ্ছে...</p>
    </div>
  );
};

export default SplashScreen;
