
import React, { useState } from 'react';
import { Division } from '../types';
import { DIVISIONS } from '../constants';
import { LocationIcon, ChevronDownIcon } from './icons';

interface HeaderProps {
  selectedDivision: Division;
  onDivisionChange: (division: Division) => void;
  lastUpdated: Date;
}

const Header: React.FC<HeaderProps> = ({ selectedDivision, onDivisionChange, lastUpdated }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (division: Division) => {
    onDivisionChange(division);
    setIsOpen(false);
  };

  return (
    <header className="container mx-auto px-4 pt-4">
      <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
        <div className="text-center sm:text-left">
          <h1 className="text-2xl font-bold text-emerald-700 font-['Hind_Siliguri']">বাংলাদেশ বাজার মূল্য</h1>
          <p className="text-sm text-gray-500">
             সর্বশেষ আপডেট: {lastUpdated.toLocaleTimeString('bn-BD')}
          </p>
        </div>
        <div className="relative">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center justify-between w-48 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-left hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
          >
            <div className="flex items-center">
              <LocationIcon className="h-5 w-5 text-gray-500 mr-2" />
              <span className="font-semibold">{selectedDivision.bn_name}</span>
            </div>
            <ChevronDownIcon className={`h-5 w-5 text-gray-500 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} />
          </button>
          {isOpen && (
            <div className="absolute mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
              <ul>
                {DIVISIONS.map(division => (
                  <li
                    key={division.name}
                    onClick={() => handleSelect(division)}
                    className="px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 cursor-pointer"
                  >
                    {division.bn_name}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
