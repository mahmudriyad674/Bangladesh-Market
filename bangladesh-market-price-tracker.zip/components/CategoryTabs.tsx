
import React from 'react';
import { Category } from '../types';

interface CategoryTabsProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
}

const CategoryTabs: React.FC<CategoryTabsProps> = ({ categories, selectedCategory, onSelectCategory }) => {
  return (
    <div className="border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex space-x-2 overflow-x-auto py-2 -mb-px">
          {categories.map(category => {
            const isActive = selectedCategory === category.id;
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => onSelectCategory(category.id)}
                className={`flex items-center space-x-2 px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-gray-600 hover:bg-emerald-50'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{category.name_bn}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CategoryTabs;
