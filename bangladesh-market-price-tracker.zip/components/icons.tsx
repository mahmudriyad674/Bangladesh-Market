import React from 'react';

// Props for all icons
interface IconProps {
  className?: string;
}

export const FishIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 10.5C10.5 9.39543 11.3954 8.5 12.5 8.5C13.6046 8.5 14.5 9.39543 14.5 10.5C14.5 11.6046 13.6046 12.5 12.5 12.5C11.3954 12.5 10.5 11.6046 10.5 10.5Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.7821 13.1111C21.75 13.5 21.75 10.5 19.7821 10.8889C19.7821 10.8889 16 10 12.5 10C9 10 4.21795 10.8889 4.21795 10.8889C2.25 10.5 2.25 13.5 4.21795 13.1111C4.21795 13.1111 9 14 12.5 14C16 14 19.7821 13.1111 19.7821 13.1111Z" />
  </svg>
);

export const MeatIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.1118 10.3298C15.1118 10.3298 17.0655 7.63205 18.5283 6.16922C20.7259 3.97163 20.7259 3.97163 17.7979 1L15.1118 3.68614L12.4256 1L9.00002 4.42562L12.4256 7.85125L10.3298 9.94709C8.42502 11.8519 11.0112 14.438 12.9159 12.5332L15.1118 10.3298Z"/>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.3298 9.94709L15.1118 15.1118C16.5 16.5 18.5 18 18.5 20C18.5 22 16.5 23 15.5 23C13.5 23 11 20.5 11 18.5C11 17 12 16 12.5 15.5L10.3298 9.94709Z"/>
  </svg>
);

export const FruitIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
     <path strokeLinecap="round" strokeLinejoin="round" d="M12 21C16.4183 21 20 17.4183 20 13C20 8.58172 16.4183 5 12 5C7.58172 5 4 8.58172 4 13C4 17.4183 7.58172 21 12 21Z" />
     <path strokeLinecap="round" strokeLinejoin="round" d="M16 8C16 5.79086 14.2091 4 12 4C9.79086 4 8 5.79086 8 8" />
  </svg>
);

export const VegetableIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 21.36a1 1 0 01-1 1H9a1 1 0 01-1-1v-1.12a2.88 2.88 0 00-.51-1.68l-2.4-4.2a1.35 1.35 0 01-.29-.8V8.34a1.36 1.36 0 011.37-1.36h7.73A1.36 1.36 0 0117.6 8.34v4.22a1.35 1.35 0 01-.29.8l-2.4 4.2a2.88 2.88 0 00-.51 1.68zm-5-17.86a2.5 2.5 0 00-2.5 2.5 1 1 0 01-2 0A4.5 4.5 0 0111 1.5a1 1 0 010 2zm6 2.5a2.5 2.5 0 00-2.5-2.5 1 1 0 110-2 4.5 4.5 0 014.5 4.5 1 1 0 01-2 0z"/>
    </svg>
);


export const SpiceIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.5 7.5C17.5 12.3333 11 15.5 11 21.5"/>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.5 2C11.5 2 11.5 5.5 13.5 7.5C15.5 9.5 17.5 7.5 17.5 7.5"/>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.5 2C11.5 2 11.5 5.5 9.5 7.5C7.5 9.5 5.5 7.5 5.5 7.5"/>
    </svg>
);

export const GroceryIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
  </svg>
);

export const AllIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
  </svg>
);

export const SearchIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
);

export const BasketIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
    </svg>
);

export const LocationIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

export const ChevronDownIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
    </svg>
);