
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden transform hover:-translate-y-1 hover:shadow-lg transition-all duration-300 group">
      <div className="w-full h-32 sm:h-40 overflow-hidden">
        <img
          src={product.image_url}
          alt={product.name_bn}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-3">
        <h3 className="text-md font-bold text-gray-800 truncate" title={product.name_bn}>
          {product.name_bn}
        </h3>
        <div className="flex items-end justify-between mt-2">
          <p className="text-lg font-bold text-emerald-600">
            ৳{product.price}
          </p>
          <p className="text-xs text-gray-500">
            /{product.unit}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
